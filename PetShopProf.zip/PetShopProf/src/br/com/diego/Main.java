package br.com.diego.lab;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Detalhe para o professor: Aplicação de Listas
        List<Pet> listaPet = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean controle = true;

        System.out.println("===================================");
        System.out.println("Seja Bem Vindo ao PetShop do Povo");
        System.out.println("===================================");

        do {
            System.out.println();
            System.out.println("Escolha uma das opções");
            System.out.println("1 - Adicionar novo pet");
            System.out.println("2 - Mostrar pets cadastrados");
            System.out.println("3 - Buscar pet por nome");
            System.out.println("4 - Finalizar programa");
            int escolha = sc.nextInt();

            switch (escolha) {
                case 1:
                    Pet pet = new Pet();
                    System.out.println("Digite o nome do pet: ");
                    pet.nome = sc.next();
                    System.out.println("Digite a idade do pet: ");
                    pet.idade = sc.nextInt();
                    System.out.println("Digite a raca do pet: ");
                    pet.raca = sc.next();
                    System.out.println("Digite o peso do pet: ");
                    pet.peso = sc.nextDouble();
                    listaPet.add(pet);
                    break;
                case 2:
                    for (Pet p : listaPet) {
                        System.out.println();
                        System.out.println("======================================");
                        System.out.println("O nome do pet é: " + p.nome);
                        System.out.println("A idade do pet é: " + p.idade);
                        System.out.println("A raça do pet é: " + p.raca);
                        System.out.println("O peso do pet é: " + p.peso);
                        System.out.println("======================================");
                    }
                    break;
                case 3:

                    buscarPet(listaPet, sc);
                    break;
                case 4:
                    controle = false;
                    break;
                default:
                    System.out.println("Seu animal, isso não é opção");
                    break;
            }
        } while (controle);
    }

    public static void buscarPet(List<Pet> lista, Scanner sc) {
        System.out.println("Digite o nome do pet para buscar: ");
        String nomeBuscado = sc.next();
        boolean achou = false;

        for (Pet p : lista) {
            if (p.nome.equalsIgnoreCase(nomeBuscado)) {
                System.out.println("Pet achado! Raça: " + p.raca + " | Idade: " + p.idade);
                achou = true;
            }
        }

        if (achou == false) {
            System.out.println("Esse pet não está cadastrado.");
        }
    }
}
package br.com.diego.lab;

public class Pet {
    String nome;
    int idade;
    String raca;
    double peso;
}
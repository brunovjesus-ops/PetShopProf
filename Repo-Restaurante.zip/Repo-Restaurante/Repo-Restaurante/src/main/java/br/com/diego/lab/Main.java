package br.com.diego.lab;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean controle = true;

        do {
            int escolha = getEscolha(sc);
            sc.nextLine();
            switch (escolha) {
                case 1:
                    loginUsuario(sc);
                    break;
                case 2:
                    controle = false;
                    break;
                default:
                    System.out.println("Opcao invalida");
                    break;
            }
        } while (controle);
    }
    private static int getEscolha(Scanner sc) {
        System.out.println("1 - login");
        System.out.println("2 - Encerrar Programa");
        int escolha = sc.nextInt();
        return escolha;
    }

    private static void loginUsuario(Scanner sc) {
        System.out.println("Digite o login do usuario");
        String usuario = sc.nextLine();
        System.out.println("Digite o senha do usuario");
        String senha = sc.nextLine();
        Usuario u = new Usuario();

        if (u.usuario.equals(usuario) && u.senha.equals(senha)) {
            boolean controleSubMenu = true;

            List<String> listaPedidos = new ArrayList<>();
            do {
                int opcaoSubMenu = getOpcaoSubMenu(sc);
                sc.nextLine();
                switch (opcaoSubMenu) {
                    case 1:
                        realizarPedido(sc, listaPedidos);
                        break;
                    case 2:
                        verStatusPedido();
                        break;
                    case 3:
                        editarPedido();
                        break;
                    case 4:
                        excluirPedidos(listaPedidos);
                        break;
                    case 5:
                        verPedidos(listaPedidos);
                        break;
                    case 6:
                        controleSubMenu = false;
                }
            } while (controleSubMenu);

        } else {
            System.out.println("Login ou senha incorretos");
        }
    }

    private static void verPedidos(List<String> listaPedidos) {
//
//        }
        System.out.println(listaPedidos);
    }

    private static void excluirPedidos(List<String> listaPedidos) {
        listaPedidos.clear();
        System.out.println("Todos os pedidos foram apagados com sucesso!");
    }

    private static void editarPedido() {
    }

    private static void verStatusPedido() {
    }

    private static void realizarPedido(Scanner sc, List<String> listaPedidos) {

        System.out.println("Escolha um dos pratos");
        System.out.println("1 - Cachorro Quente");
        System.out.println("2 - Baguncinha");
        System.out.println("3 - Pizza");
        System.out.println("4 - Sushi");
        int prato = sc.nextInt();
        sc.nextLine();
        switch (prato) {
            case 1:
                listaPedidos.add("Cachorro Quente");
                break;
            case 2:
                listaPedidos.add("Baguncinha");
                break;
            case 3:
                listaPedidos.add("Pizza");
                break;
            case 4:
                listaPedidos.add("Sushi");
                break;
            default:
                System.out.println("Opcao invalida");

        }
    }

    private static int getOpcaoSubMenu(Scanner sc) {
        System.out.println("Login efetuado com sucesso");
        System.out.println("1 - Fazer pedido");
        System.out.println("2 - Ver status do pedido");
        System.out.println("3 - Editar pedido");
        System.out.println("4 - Excluir pedido");
        System.out.println("5 - Ver pedidos");
        System.out.println("6 - logout");
        int opcaoSubMenu = sc.nextInt();
        return opcaoSubMenu;
    }
}
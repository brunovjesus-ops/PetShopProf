package br.com.diego.lab;

public class Usuario {
    String usuario = "admin123";
    String senha = "admin123";
}
